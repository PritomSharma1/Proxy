import os

os.system('pip install --upgrade pip')
os.system('pip install python-telegram-bot==13.15')
os.system("pip install telethon")
os.system("pip install jdatetime")
os.system("pip install requests")
os.system("pip install pymysql")
os.system("pip install psutil")
os.system("pip install pytz")
os.system("pip install phonenumbers")
