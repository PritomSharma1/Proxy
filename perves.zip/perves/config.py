admins = [5373443138] # Admins UserIDs
token = "7384724696:AAFdsCe9at1oER7LLTn3_qZVhpQMl38Vqaw" # Token Bot

host_db = 'localhost'
database = '' # Database Name
user_db = '' # Database Username
passwd_db = '' # Database Password
port = 3306

python_version = "python"
