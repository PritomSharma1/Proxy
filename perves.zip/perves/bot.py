import os, re, time, shutil, phonenumbers, telegram, telegram.ext, utility as utl


directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))

utl.get_params_pids_by_full_script_name(script_names=[f"{directory}/{filename}"], is_kill_proccess=True)
print(f"ok: {filename}")

if not os.path.exists(f"{directory}/sessions"):
    os.mkdir(f"{directory}/sessions")
if not os.path.exists(f"{directory}/data"):
    os.mkdir(f"{directory}/data")


def user_panel(message, text=None):
    if not text:
        text = "یکی از گزینه های زیر را انتخاب کنید:"
    message.reply_html(text=text,
        reply_markup={'resize_keyboard': True, 'keyboard': [
            [{'text': '📤 ارسال اکانت'}],
            [{'text': '☎️ پشتیبانی'}, {'text': '👤 حساب کاربری'}],
            [{'text': '🌎 کشور های مجاز'}, {'text': '✅ تسویه حساب'}],
        ]}
    )


def callbackquery_process(update: telegram.Update, context: telegram.ext.CallbackContext) -> None:
    bot = context.bot
    query = update.callback_query
    from_id = query.from_user.id
    message = query.message
    message_id = message.message_id
    chat_id = message.chat.id
    data = query.data
    ex_data = data.split(';')
    timestamp = int(time.time())
    try:
        if data == "nazan":
            return query.answer(text="نزن خراب میشه 😕", show_alert=True)
        elif data == "delete":
            message.delete()
            if message.reply_to_message:
                message.reply_to_message.delete()
            return
        
        cs = utl.Database()
        cs = cs.data()

        cs.execute(f"SELECT * FROM {utl.admin}")
        row_admin = cs.fetchone()
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={from_id}")
        row_user = cs.fetchone()

        if data == 'start':
            if not row_admin['onoff_bot']:
                return message.reply_html(text="ربات به دلیل تعمیرات خاموش است، لطفا دقایقی دیگر تلاش کنید", reply_to_message_id=message_id)
            try:
                inline_keyboard = []
                if row_admin['channel_1'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_1']}", user_id=from_id).status == "left":
                    inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_1']}"}])
                elif row_admin['channel_2'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_2']}", user_id=from_id).status == "left":
                    inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_2']}"}])
                elif row_admin['channel_3'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_3']}", user_id=from_id).status == "left":
                    inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_3']}"}])
                if inline_keyboard:
                    return query.answer(text="⚠️ شما هنوز در کانال های ما عضو نشده اید", show_alert=True)
            except:
                pass
            cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id={from_id}")
            user_panel(message)
            return message.delete()
        elif ex_data[0] == 'confirm_phone':
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_data[1])} AND status=3")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                return query.answer(text="❌ عملیات منقضی شده", show_alert=True)
            else:
                if row_mbots['last_check_exit_count'] > 0:
                    row_admin['time_logout_account'] = 10
                if (timestamp - row_mbots['last_check_exit_at']) < row_admin['time_logout_account']:
                    time_waite = row_admin['time_logout_account'] - (timestamp - row_mbots['last_check_exit_at'])
                    return query.answer(text=f"⚠️ لطفا {time_waite} ثانیه دیگر تلاش کنید", show_alert=True)
                else:
                    cs.execute(f"UPDATE {utl.mbots} SET last_check_exit_at={timestamp},last_check_exit_count=last_check_exit_count+1 WHERE id={row_mbots['id']}")
                    info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                    os.system(f"{utl.python_version} \"{directory}/tl_account.py\" {row_mbots['uniq_id']} {message_id} session")
                    return info_msg.delete()
        if from_id in utl.admins or row_user['status'] == 1:
            if ex_data[0] == 'pg':
                if ex_data[1] == 'accounts':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id IS NOT NULL ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            if row['status'] == 2:
                                output += f"{i}. Phone: <code>{row['phone']}</code>\n"
                                output += f"⛔ Restrict: ({utl.convert_time((row['end_restrict'] - timestamp),2)})\n"
                            else:
                                output += f"{i}. phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                            output += f"🔸️ Status: /status_{row['id']}\n"
                            if row['status'] != 0:
                                output += f"🔸️ Get Session: /session_{row['id']}\n"
                                output += f"🔸️ Delete Sessions: /del_session_{row['id']}\n"
                                output += f"🔸️ Delete Password: /del_password_{row['id']}\n"
                            output += "\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست همه اکانت ها ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update, "accounts", output, utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'first_level':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=0 ORDER BY last_order_at DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. Phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                            output += f"🔸️ Status: /status_{row['id']}\n"
                            output += "\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=0")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست اکانت های ثبت نشده ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update,"first_level",output,utl.step_page,rowcount)
                        return ob.process()
                elif ex_data[1] == 'submitted':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=1 ORDER BY last_order_at ASC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. Phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                            output += f"🔸️ Status: /status_{row['id']}\n"
                            output += f"🔸️ Get Session: /session_{row['id']}\n"
                            output += f"🔸️ Delete Sessions: /del_session_{row['id']}\n"
                            output += f"🔸️ Delete Password: /del_password_{row['id']}\n"
                            output += "\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=1")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست اکانت های فعال ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update, "submitted", output, utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'waite_exit':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=3 ORDER BY last_order_at ASC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. Phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                            output += f"🔸️ Status: /status_{row['id']}\n"
                            output += f"🔸️ Get Session: /session_{row['id']}\n"
                            output += f"🔸️ Delete Sessions: /del_session_{row['id']}\n"
                            output += f"🔸️ Delete Password: /del_password_{row['id']}\n"
                            output += "\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=1")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست اکانت های در انتظار خروج ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update, "waite_exit", output, utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'apis':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"🔴️ Api ID: <code>{row['api_id']}</code>\n"
                            output += f"🔴️ Api Hash: <code>{row['api_hash']}</code>\n"
                            output += f"❌ Delete: /DeleteApi_{row['id']}\n\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.apis}")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست ای پی ای ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update, "apis", output, utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'withdrawal':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.withdrawal} ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"🔰 شناسه: /w_{row['id']} ({utl.status_withdrawal[row['status']]})\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.withdrawal}")
                        rowcount = cs.fetchone()['count']
                        output = f"📜 لیست تسویه حساب ({rowcount})\n\n{output}"
                        ob = utl.Pagination(update, "withdrawal", output, utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'users':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.users} ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.users}")
                        rowcount = cs.fetchone()['count']
                        ob = utl.Pagination(update, "users",f"📜 لیست کاربران ({rowcount})\n\n{output}", utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'admins':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.users} WHERE status=1 ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.users} WHERE status=1")
                        rowcount = cs.fetchone()['count']
                        ob = utl.Pagination(update, "admins",f"📜 لیست ادمین ها ({rowcount})\n\n{output}", utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1] == 'blocked':
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.users} WHERE status=2 ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.users} WHERE status=2")
                        rowcount = cs.fetchone()['count']
                        ob = utl.Pagination(update, "blocked",f"📜 لیست بلاک ها ({rowcount})\n\n{output}", utl.step_page, rowcount)
                        return ob.process()
                elif ex_data[1][0:10] == 'accountsu_':
                    user_id_select = int(ex_data[1][10:])
                    selected_pages = (int(ex_data[2]) - 1) * utl.step_page
                    i = selected_pages + 1
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE creator_user_id={user_id_select} AND user_id IS NOT NULL ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⚠️ صفحه دیگری وجود ندارد", show_alert=True)
                    else:
                        output = ""
                        for row in result:
                            if row['status'] == 2:
                                output += f"{i}. Phone: <code>{row['phone']}</code>\n"
                                output += f"⛔ Restrict: ({utl.convert_time((row['end_restrict'] - timestamp),2)})\n"
                            else:
                                output += f"{i}. phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                            output += f"🔸️ Status: /status_{row['id']}\n"
                            if row['status'] != 0:
                                output += f"🔸️ Get Session: /session_{row['id']}\n"
                                output += f"🔸️ Delete Sessions: /del_session_{row['id']}\n"
                                output += f"🔸️ Delete Password: /del_password_{row['id']}\n"
                            output += "\n"
                            i += 1
                        cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE creator_user_id={user_id_select} AND user_id IS NOT NULL")
                        rowcount = cs.fetchone()['count']
                        ob = utl.Pagination(update, f"accountsu_{user_id_select}", f"📜 لیست اکانت های کاربر {user_id_select} ({rowcount})\n\n{output}", utl.step_page, rowcount)
                        return ob.process()
            elif ex_data[0] == 'settings':
                if ex_data[1] == 'change_pass' or ex_data[1] == 'is_change_profile' or ex_data[1] == 'is_set_username' or ex_data[1] == 'onoff_bot' or ex_data[1] == 'onoff_account' or ex_data[1] == 'onoff_withdrawal' or ex_data[1] == 'onoff_support':
                    row_admin[ex_data[1]] = 1 - row_admin[ex_data[1]]
                    cs.execute(f"UPDATE {utl.admin} SET {ex_data[1]}={row_admin[ex_data[1]]}")
                elif ex_data[1] == 'account_password':
                    cs.execute(f"UPDATE {utl.users} SET step='set_pass;none' WHERE user_id={from_id}")
                    return query.edit_message_text(text="پسورد جدید را وارد کنید:")
                else:
                    number = int(ex_data[2])
                    if ex_data[1] == 'api_per_number':
                        row_admin['api_per_number'] += number
                        if row_admin['api_per_number'] < 1:
                            return query.answer(text="❌ حداقل باید 1 باشه")
                        else:
                            cs.execute(f"UPDATE {utl.admin} SET api_per_number={row_admin['api_per_number']}")
                    elif ex_data[1] == 'time_logout_account':
                        row_admin['time_logout_account'] += number
                        if row_admin['time_logout_account'] < 10:
                            return query.answer(text="❌ حداقل باید 10 باشه")
                        else:
                            cs.execute(f"UPDATE {utl.admin} SET time_logout_account={row_admin['time_logout_account']}")
                    else:
                        return
                account_password = row_admin['account_password'] if row_admin['account_password'] is not None else "ثبت نشده"
                api_per_number = f"ثبت {row_admin['api_per_number']} اکانت در هر api" if row_admin['api_per_number'] <= 5 else f"⚠️ ثبت {row_admin['api_per_number']} اکانت در هر api ⚠️"
                change_pass = "✅ تغییر / تنظیم پسورد روی اکانت ✅" if row_admin['change_pass'] else "❌ تغییر / تنظیم پسورد روی اکانت ❌"
                is_change_profile = "✅ تنظیم اسم، بیو و پروفایل روی اکانت ✅" if row_admin['is_change_profile'] else "❌ تنظیم اسم، بیو و پروفایل روی اکانت ❌"
                is_set_username = "✅ تنظیم یوزرنیم روی اکانت ✅" if row_admin['is_set_username'] else "❌ تنظیم یوزرنیم روی اکانت ❌"
                onoff_bot = "✅ ربات روشن است" if row_admin['onoff_bot'] else "❌ ربات خاموش است"
                onoff_account = "✅ ارسال اکانت روشن است" if row_admin['onoff_account'] else "❌ ارسال اکانت خاموش است"
                onoff_withdrawal = "✅ تسویه حساب روشن است" if row_admin['onoff_withdrawal'] else "❌ تسویه حساب خاموش است"
                onoff_support = "✅ پشتیبانی روشن است" if row_admin['onoff_support'] else "❌ پشتیبانی خاموش است"
                return query.edit_message_text(
                    text="⚙️ تنظیمات:",
                    reply_markup={'inline_keyboard': [
                        [{'text': f"پسورد: {account_password}",'callback_data': "settings;account_password"}],
                        [{'text': api_per_number,'callback_data': "nazan"}],
                        [
                            {'text': '+10','callback_data': "settings;api_per_number;+10"},
                            {'text': '+5','callback_data': "settings;api_per_number;+5"},
                            {'text': '+1','callback_data': "settings;api_per_number;+1"},
                            {'text': '-1','callback_data': "settings;api_per_number;-1"},
                            {'text': '-5','callback_data': "settings;api_per_number;-5"},
                            {'text': '-10','callback_data': "settings;api_per_number;-10"},
                        ],
                        [{'text': f"خروج از اکانت بعد از {row_admin['time_logout_account']} ثانیه",'callback_data': "nazan"}],
                        [
                            {'text': '+10','callback_data': "settings;time_logout_account;+100"},
                            {'text': '+5','callback_data': "settings;time_logout_account;+10"},
                            {'text': '+1','callback_data': "settings;time_logout_account;+5"},
                            {'text': '-1','callback_data': "settings;time_logout_account;-5"},
                            {'text': '-5','callback_data': "settings;time_logout_account;-10"},
                            {'text': '-10','callback_data': "settings;time_logout_account;-100"},
                        ],
                        [{'text': change_pass,'callback_data': "settings;change_pass"}],
                        [{'text': is_change_profile,'callback_data': "settings;is_change_profile"}],
                        [{'text': is_set_username,'callback_data': "settings;is_set_username"}],
                        [{'text': "〰️〰️〰️ روشن / خاموش〰️〰️〰️",'callback_data': "nazan"}],
                        [{'text': onoff_bot,'callback_data': "settings;onoff_bot"}],
                        [{'text': onoff_account,'callback_data': "settings;onoff_account"}],
                        [{'text': onoff_withdrawal,'callback_data': "settings;onoff_withdrawal"}],
                        [{'text': onoff_support,'callback_data': "settings;onoff_support"}],
                    ]}
                )
            elif ex_data[0] == "d":
                cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={int(ex_data[1])}")
                row_user_select = cs.fetchone()
                if row_user_select is None:
                    return query.answer(text="❌ شناسه اشتباه است")
                else:
                    value = ex_data[2]
                    if value == 'balance':
                        change_balance = row_user_select['balance'] + int(ex_data[3])
                        if change_balance <= 0:
                            if not row_user_select['balance']:
                                return query.answer(text="❌ عملیات نامعتبر", show_alert=True)
                            else:
                                row_user_select['balance'] = 0
                        else:
                            row_user_select['balance'] = change_balance
                        cs.execute(f"UPDATE {utl.users} SET balance={row_user_select['balance']} WHERE user_id={row_user_select['user_id']}")
                    elif value == "sendmsg":
                        cs.execute(f"UPDATE {utl.users} SET step='sendmsg;{row_user_select['user_id']}' WHERE user_id={from_id}")
                        return bot.send_message(
                            chat_id=chat_id,
                            text="پیام را ارسال کنید:\n"
                                "کنسل: /panel"
                        )
                    else:
                        status = int(value)
                        if row_user_select['status'] == 1 or status == 1:
                            if from_id in utl.admins:
                                cs.execute(f"UPDATE {utl.users} SET status={status} WHERE user_id={row_user_select['user_id']}")
                            else:
                                return query.answer(text="⛔️ این قابلیت مخصوص ادمین اصلی است", show_alert=True)
                        else:
                            cs.execute(f"UPDATE {utl.users} SET status={status} WHERE user_id={row_user_select['user_id']}")
                    cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={row_user_select['user_id']}")
                    row_user_select = cs.fetchone()
                    block = 'بلاک ✅' if row_user_select['status'] == 2 else 'بلاک ❌'
                    block_status = 0 if row_user_select['status'] == 2 else 2
                    admin = 'ادمین ✅' if row_user_select['status'] == 1 else 'ادمین ❌'
                    admin_status = 0 if row_user_select['status'] == 1 else 1
                    return message.edit_text(
                        text=f"کاربر <a href='tg://user?id={row_user_select['user_id']}'>{row_user_select['user_id']}</a>",
                        parse_mode='HTML',
                        reply_markup={'inline_keyboard': [
                            [{'text': "ارسال پیام",'callback_data': f"d;{row_user_select['user_id']};sendmsg"}],
                            [
                                {'text': block,'callback_data': f"d;{row_user_select['user_id']};{block_status}"},
                                {'text': admin,'callback_data': f"d;{row_user_select['user_id']};{admin_status}"}
                            ],
                            [{'text': f"موجودی: {row_user_select['balance']}",'callback_data': "nazan"}],
                            [
                                {'text': '+5000','callback_data': f"d;{row_user_select['user_id']};balance;+5000"},
                                {'text': '+1000','callback_data': f"d;{row_user_select['user_id']};balance;+1000"},
                                {'text': '-1000','callback_data': f"d;{row_user_select['user_id']};balance;-1000"},
                                {'text': '-5000','callback_data': f"d;{row_user_select['user_id']};balance;-5000"},
                            ],
                        ]}
                    )
            elif ex_data[0] == 'gc':
                if ex_data[1] == 'delete_logout':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status=0")
                    result = cs.fetchall()
                    if result:
                        for row_mbots in result:
                            cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row_mbots['id']}")
                            utl.remove_path(f"{directory}/sessions/{row_mbots['uniq_id']}.session")
                        return message.reply_html(text="✅ {len(result)} unregistered accounts were deleted")
                    else:
                        return query.answer(text="❌ هیچ اکانتی یافت نشد", show_alert=True)
                elif ex_data[1] == 'leave_channel':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status>0 AND ({timestamp}-last_leave_at)>86400 LIMIT 1")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⛔️ هیچ اکانتی یافت نشد، هر اکانت در 24 ساعت 1 بار چک می شود", show_alert=True)
                    else:
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        count_analyzable = cs.rowcount
                        count_analyze = 0
                        for row_mbots in result:
                            count_analyze += 1
                            os.system(f"{utl.python_version} \"{directory}/tl_leave.py\" {row_mbots['uniq_id']} {from_id} channel {info_msg.message_id} \"{count_analyze},{count_analyzable},{timestamp}\"")
                        message.reply_html(
                            text="✅ ترک گروه و کانال ها اتمام یافت\n\n"
                                f"👤 اکانت ها: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                "➖➖➖➖➖➖\n"
                                f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                        )
                        return info_msg.delete()
                elif ex_data[1] == 'leave_private':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status>0 AND ({timestamp}-last_delete_chats_at)>86400 LIMIT 1")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⛔️ هیچ اکانتی یافت نشد، هر اکانت در 24 ساعت 1 بار چک می شود", show_alert=True)
                    else:
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        count_analyzable = cs.rowcount
                        count_analyze = 0
                        for row_mbots in result:
                            count_analyze += 1
                            os.system(f"{utl.python_version} \"{directory}/tl_leave.py\" {row_mbots['uniq_id']} {from_id} private {info_msg.message_id} \"{count_analyze},{count_analyzable},{timestamp}\"")
                        message.reply_html(
                            text="✅ حذف پیوی ها اتمام یافت\n\n"
                                f"👤 اکانت ها: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                "➖➖➖➖➖➖\n"
                                f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                        )
                        return info_msg.delete()
                elif ex_data[1] == 'leave_chat':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status>0 AND (({timestamp}-last_leave_at)>86400 OR ({timestamp}-last_delete_chats_at)>86400) LIMIT 1")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⛔️ هیچ اکانتی یافت نشد، هر اکانت در 24 ساعت 1 بار چک می شود", show_alert=True)
                    else:
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        count_analyzable = cs.rowcount
                        count_analyze = 0
                        for row_mbots in result:
                            count_analyze += 1
                            os.system(f"{utl.python_version} \"{directory}/tl_leave.py\" {row_mbots['uniq_id']} {from_id} all {info_msg.message_id} \"{count_analyze},{count_analyzable},{timestamp}\"")
                        message.reply_html(
                            text="✅ ترک گروه و کانال و حذف پیوی ها اتمام یافت\n\n"
                                f"👤 اکانت ها: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                "➖➖➖➖➖➖\n"
                                f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                        )
                        return info_msg.delete()
                elif ex_data[1] == 'delete_password':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status=1")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⛔️ در حال حاضر هیچ اکانتی وجود ندارد", show_alert=True)
                    elif ex_data[2] == 'none':
                        return message.reply_html(
                            text="❗️ آیا مطمعن هستید می خواهید پسورد تمام اکانت ها حذف شوند؟",
                            reply_to_message_id=message_id,
                            reply_markup={'inline_keyboard': [[{'text': '❌ انصراف ❌', 'callback_data': "delete"}, {'text': '✅ بله انجام بده ✅', 'callback_data': f"{ex_data[0]};{ex_data[1]};confirm"}]]}
                        )
                    elif ex_data[2] == 'confirm':
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        count_analyzable = len(result)
                        count_analyze = 0
                        for row_mbots in result:
                            count_analyze += 1
                            try:
                                info_msg.edit_text(
                                    text="⏳ در حال حذف پسورد ها ...\n\n"
                                        f"👤 اکانت: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                        f"♻️ پیشرفت: <b>{(count_analyze / count_analyzable * 100):,.2f}%</b>\n"
                                        "➖➖➖➖➖➖\n"
                                        f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                                )
                            except:
                                pass
                            os.system(f"{utl.python_version} \"{directory}/tl_delete_password.py\" {row_mbots['uniq_id']} {from_id} all")
                        message.reply_html(
                            text="✅ حذف پسورد ها اتمام یافت\n\n"
                                f"👤 اکانت ها: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                "➖➖➖➖➖➖\n"
                                f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                        )
                        return info_msg.delete()
                elif ex_data[1] == 'get_session':
                    cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE status=1")
                    count_accounts = cs.fetchone()['count']
                    if count_accounts < 1:
                        return query.answer(text="⛔️ در حال حاضر هیچ اکانتی وجود ندارد", show_alert=True)
                    else:
                        cs.execute(f"UPDATE {utl.users} SET step='get_sessions;none' WHERE user_id={from_id}")
                        return message.reply_html(
                            text=f"تعداد را ارسال کنید (بین 1 تا <code>{count_accounts}</code>):\n"
                                "کنسل: /panel"
                        )
                elif ex_data[1] == 'del_sessions':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE status=1")
                    result = cs.fetchall()
                    if not result:
                        return query.answer(text="⛔️ در حال حاضر هیچ اکانتی وجود ندارد", show_alert=True)
                    elif ex_data[2] == 'none':
                        return message.reply_html(
                            text="❗️ آیا مطمعن هستید می خواهید تمام اکانت ها از همه سشن ها (بجز سشن ربات) لاگ اوت شوند؟",
                            reply_to_message_id=message_id,
                            reply_markup={'inline_keyboard': [[{'text': '❌ انصراف ❌', 'callback_data': "delete"}, {'text': '✅ بله انجام بده ✅', 'callback_data': f"{ex_data[0]};{ex_data[1]};confirm"}]]}
                        )
                    elif ex_data[2] == 'confirm':
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        count_analyzable = len(result)
                        count_analyze = 0
                        for row_mbots in result:
                            count_analyze += 1
                            try:
                                info_msg.edit_text(
                                    text="⏳ در حال پایان دادن به نشست ها ...\n\n"
                                        f"👤 اکانت: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                        f"♻️ پیشرفت: <b>{(count_analyze / count_analyzable * 100):,.2f}%</b>\n"
                                        "➖➖➖➖➖➖\n"
                                        f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                                )
                            except:
                                pass
                            os.system(f"{utl.python_version} \"{directory}/tl_delete_sessions.py\" {row_mbots['uniq_id']} {from_id} all")
                        message.reply_html(
                            text="✅ پایان دادن به سشن ها اتمام یافت\n\n"
                                f"👤 اکانت ها: <b>[{count_analyze:,} / {count_analyzable:,}]</b>\n"
                                "➖➖➖➖➖➖\n"
                                f"📅 مدت زمان: <b>{utl.convert_time((int(time.time()) - timestamp), 2)}</b>",
                        )
                        return info_msg.delete()
                elif ex_data[1] == 'logout':
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_data[2])}")
                    row_mbots = cs.fetchone()
                    if row_mbots is None or row_mbots['status'] == 0:
                        if row_mbots is not None:
                            cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row_mbots['id']}")
                        query.answer(text="✅ انجام شد", show_alert=True)
                        return message.delete()
                    elif ex_data[3] == 'none':
                        return message.reply_html(
                            text=f"❗️ آیا مطمعن هستید می خواهید از اکانت <code>{row_mbots['phone']}</code> لاگ اوت شوید؟\n\n"
                                "⚠️ بعد از لاگ اوت دیگر به اکانت دسترسی نخواهید داشت",
                            reply_to_message_id=message_id,
                            reply_markup={'inline_keyboard': [[{'text': '❌ انصراف ❌', 'callback_data': "delete"}, {'text': '✅ بله انجام بده ✅', 'callback_data': f"{ex_data[0]};{ex_data[1]};{ex_data[2]};confirm"}]]}
                        )
                    elif ex_data[3] == 'confirm':
                        info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …")
                        os.system(f"{utl.python_version} \"{directory}/tl_logout.py\" {row_mbots['uniq_id']} {from_id}")
                        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={row_mbots['id']}")
                        row_mbots = cs.fetchone()
                        if row_mbots is None:
                            info_msg.edit_text(text="✅ اکانت لاگ اوت شد")
                            return message.edit_reply_markup(reply_markup={'inline_keyboard': [[{'text': '✅ اکانت لاگ اوت شد ✅', 'callback_data': "nazan"}]]})
                        else:
                            return info_msg.edit_text(text="❌ خطایی هنگام لاگ اوت رخ داد")
            elif ex_data[0] == 'withdrawal':
                cs.execute(f"SELECT * FROM {utl.withdrawal} WHERE id={int(ex_data[1])}")
                row_withdrawal = cs.fetchone()
                if row_withdrawal is None:
                    return query.answer(text="❌ شناسه اشتباه است", show_alert=True)
                elif ex_data[2] == 'accept':
                    cs.execute(f"UPDATE {utl.withdrawal} SET status=2 WHERE id={row_withdrawal['id']}")
                    message.edit_reply_markup(reply_markup={'inline_keyboard': [[{'text': "ارسال پیام",'callback_data': f"d;{row_withdrawal['user_id']};sendmsg"}]]})
                    if row_withdrawal['status'] == 2:
                        return query.answer(text="❌ این تسویه قبلا انجام شده", show_alert=True)
                    bot.send_message(
                        chat_id=from_id,
                        text="✅ تسویه حساب با موفقیت انجام شد",
                        reply_to_message_id=message_id,
                    )
                    return bot.send_message( chat_id=row_withdrawal['user_id'], text=f"✅ تسویه حساب به شناسه {row_withdrawal['id']} و به مبلغ {row_withdrawal['amount']} تومان انجام شد")
    except telegram.error.RetryAfter:
        return query.answer(text="⚠️ کمی آرام تر با ربات کار کنید", show_alert=True)


def private_process(update: telegram.Update, context: telegram.ext.CallbackContext) -> None:
    bot = context.bot
    message = update.message
    from_id = message.from_user.id
    chat_id = message.chat.id
    first_name = message.from_user.first_name
    message_id = message.message_id
    text = message.text if message.text else ""
    if message.text:
        txtcap = message.text
    elif message.caption:
        txtcap = message.caption
    ex_text = text.split('_')
    
    timestamp = int(time.time())

    cs = utl.Database()
    cs = cs.data()

    cs.execute(f"SELECT * FROM {utl.admin}")
    row_admin = cs.fetchone()
    cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={from_id}")
    row_user = cs.fetchone()
    if row_user is None:
        cs.execute(f"INSERT INTO {utl.users} (user_id,status,step,created_at,uniq_id) VALUES ({from_id},0,'start',{timestamp},'{utl.unique_id()}')")
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={from_id}")
        row_user = cs.fetchone()
    ex_step = row_user['step'].split(';')
    
    try:
        inline_keyboard = []
        if row_admin['channel_1'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_1']}", user_id=from_id).status == "left":
            inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_1']}"}])
        if row_admin['channel_2'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_2']}", user_id=from_id).status == "left":
            inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_2']}"}])
        if row_admin['channel_3'] is not None and bot.get_chat_member(chat_id=f"@{row_admin['channel_3']}", user_id=from_id).status == "left":
            inline_keyboard.append([{'text': 'ورود به کانال', 'url': f"https://t.me/{row_admin['channel_3']}"}])
        if inline_keyboard:
            inline_keyboard.append([{'text': '✅ تایید عضویت ✅', 'callback_data': "start"}])
            return message.reply_html(
                text=f"🔥 کاربر عزیز {first_name} لطفا برای دسترسی به تمام بخش های ربات در کانال های ما عضو شوید",
                reply_markup={'inline_keyboard': inline_keyboard}
            )
    except:
        pass
    if text == '/start' or text == utl.menu_var:
        if not row_admin['onoff_bot']:
            return message.reply_html(text="ربات به دلیل تعمیرات خاموش است، لطفا دقایقی دیگر تلاش کنید", reply_to_message_id=message_id)
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id={from_id}")
        return user_panel(message)
    if row_admin['onoff_bot']:
        if ex_step[0] == 'add_acc':
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_step[2])}")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                return message.reply_html(text="❌ خطای ناشناخته!")
            elif ex_step[1] == 'phone':
                phone = text.replace("+","").replace(" ","")
                try:
                    parse_phone = phonenumbers.parse(f"+{phone}")
                    if not phonenumbers.is_possible_number(parse_phone):
                        return message.reply_html(text="❌ فرمت اشتباه شماره خود را همراه پیش شماره ارسال کنید")
                    cs.execute(f"SELECT * FROM {utl.countries} WHERE area_code={parse_phone.country_code} AND is_useable=1 AND is_exists=1")
                    row_countries = cs.fetchone()
                    if row_countries is None:
                        return message.reply_html(text="❌ این کشور در حال حاضر پشتیبانی نمی شود")
                    print(row_countries['name_en'])
                except:
                    return message.reply_html(text="❌ فرمت اشتباه شماره خود را همراه پیش شماره ارسال کنید")
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE phone='{phone}' AND status=1")
                if cs.fetchone() is not None:
                    return message.reply_html(text="❌ اکانت ارسالی شما در لیست اکانت های ربات وجود دارد لطفا اکانت دیگری را ارسال کنید")
                info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                cs.execute(f"UPDATE {utl.mbots} SET creator_user_id={from_id},phone='{phone}',country_id={row_countries['id']},amount={row_countries['amount']} WHERE id={row_mbots['id']}")
                os.system(f"{utl.python_version} \"{directory}/tl_account.py\" {row_mbots['uniq_id']} {message_id} code")
                return info_msg.delete()
            elif ex_step[1] == 'code':
                try:
                    ex_nl_text = text.split("\n")
                    if len(ex_nl_text) == 1:
                        code = int(text)
                        cs.execute(f"UPDATE {utl.mbots} SET code={code} WHERE id={row_mbots['id']}")
                    elif len(ex_nl_text) == 2:
                        code = int(ex_nl_text[0])
                        password = ex_nl_text[1]
                        if len(password) > 200:
                            return message.reply_html(text="❌ لطفا طبق توضیحات ارسال کنید!")
                        cs.execute(f"UPDATE {utl.mbots} SET code={code},password='{password}' WHERE id={row_mbots['id']}")
                    info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                    os.system(f"{utl.python_version} \"{directory}/tl_account.py\" {row_mbots['uniq_id']} {message_id} auth")
                    return info_msg.delete()
                except:
                    return message.reply_html(text="❌ لطفا طبق توضیحات ارسال کنید!")
        elif text == '📤 ارسال اکانت':
            if not row_admin['onoff_account']:
                return message.reply_html(text="❌ کاربر گرامی در حال حاضر این بخش بسته است، دقایقی دیگر تلاش کنید!")
            cs.execute(f"DELETE FROM {utl.mbots} WHERE creator_user_id={from_id} AND status=0 AND user_id IS NULL")
            row_apis = utl.select_api(cs, row_admin['api_per_number'])
            if row_apis is None:
                return message.reply_html(text="❌ در حال حاضر امکان دریافت اکانت وجود ندارد، لطفا دقایقی دیگر تلاش کنید")
            else:
                uniq_id = utl.unique_id()
                cs.execute(f"INSERT INTO {utl.mbots} (cat_id,creator_user_id,api_id,api_hash,status,created_at,uniq_id) VALUES (1,{from_id},'{row_apis['api_id']}','{row_apis['api_hash']}',0,'{timestamp}','{uniq_id}')")
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{uniq_id}'")
                row_mbots = cs.fetchone()
                if row_mbots is not None:
                    cs.execute(f"UPDATE {utl.users} SET step='add_acc;phone;{row_mbots['id']}' WHERE user_id={from_id}")
                    return message.reply_html(
                        text="🔢 شماره مجازی خود را به همراه پیش شماره ارسال کنید:",
                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
                    )
                else:
                    return message.reply_html(text="❌ مشکلی پیش آمده، مجدد تلاش کنید")
        elif text == '☎️ پشتیبانی':
            if not row_admin['onoff_support']:
                return message.reply_html(text="❌ کاربر گرامی در حال حاضر این بخش بسته است، دقایقی دیگر تلاش کنید!")
            cs.execute(f"UPDATE {utl.users} SET step='support;none' WHERE user_id={from_id}")
            return message.reply_html(
                text="جهت ارتباط به صورت مستقیم 👈🏻\n"
                    f"@{row_admin['support']}\n\n"
                    "🧑‍💻سعی بخش پشتیبانی بر این است که تمامی پیام های دریافتی در کمتر از چند ساعت پاسخ داده شوند، بنابراین تا زمان دریافت پاسخ صبور باشید !\n\n"
                    "⚠️ کاربر گرامی لطفا قبل از ارسال پیام بخش راهنما رو به طور کامل مطالعه کنید !!\n\n"
                    "💬 لطفا پیام، سوال، پیشنهاد و یا انتقاد خود را در قالب یک پیام واحد به طور کامل ارسال کنید :",
                reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
            )
        elif ex_step[0] == 'support':
            try:
                content = f"🔔 پشتیبانی جدید از (<a href='tg://user?id={from_id}'>{from_id}</a> | /d_{from_id})\n——————————————————\n{txtcap}"
                reply_markup = {'inline_keyboard': [[{'text': "ارسال پیام",'callback_data': f"d;{from_id};sendmsg"}]]}
                if message.text:
                    bot.send_message( chat_id=utl.admins[0], text=content, parse_mode='HTML', reply_markup=reply_markup)
                elif message.photo:
                    bot.send_photo(chat_id=utl.admins[0], caption=content, photo=message.photo[len(message.photo) - 1].file_id, parse_mode='HTML', reply_markup=reply_markup)
                elif message.video:
                    bot.send_video(chat_id=utl.admins[0], caption=content, video=message.video.file_id, parse_mode='HTML', reply_markup=reply_markup)
                elif message.audio:
                    bot.send_audio(chat_id=utl.admins[0], caption=content, audio=message.audio.file_id, parse_mode='HTML', reply_markup=reply_markup)
                elif message.voice:
                    bot.send_voice(chat_id=utl.admins[0], caption=content, voice=message.voice.file_id, parse_mode='HTML', reply_markup=reply_markup)
                elif message.document:
                    bot.send_document(chat_id=utl.admins[0], caption=content, document=message.document.file_id, parse_mode='HTML', reply_markup=reply_markup)
                else:
                    return message.reply_html(text="⛔️ پیام پشتیبانی نمی شود")
                cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                return message.reply_html(text="✅ پیام شما به واحد پشتیبانی ارسال شد، لطفا برای دریافت پاسخ صبور باشید  ….", reply_to_message_id=message_id)
            except:
                return message.reply_html(text="❌ خطای ناشناخته، دوباره تست کنید")
        elif text == '✅ تسویه حساب' or text == 'بازگشت به تسویه ↪️':
            cs.execute(f"DELETE FROM {utl.withdrawal} WHERE user_id={from_id} AND status=0")
            if not row_admin['onoff_withdrawal']:
                return message.reply_html(text="❌ کاربر گرامی در حال حاضر این بخش بسته است، دقایقی دیگر تلاش کنید!")
            if row_user['balance'] < row_admin['min_withdrawal']:
                return message.reply_html(text=f"موجودی شما باید حداقل {row_admin['min_withdrawal']} تومان باشد", reply_to_message_id=message_id)
            uniq_id = utl.unique_id()
            cs.execute(f"INSERT INTO {utl.withdrawal} (user_id,status,created_at,uniq_id) VALUES ({from_id},0,{timestamp},'{uniq_id}')")
            cs.execute(f"SELECT * FROM {utl.withdrawal} WHERE uniq_id='{uniq_id}'")
            row_withdrawal = cs.fetchone()
            if row_withdrawal is not None:
                cs.execute(f"UPDATE {utl.users} SET step='withdrawal;{row_withdrawal['id']};amount' WHERE user_id={from_id}")
                return message.reply_html(
                    text="💸 لطفا مبلغی که قصد برداشت آن را دارید به تومان ارسال کنید",
                    reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
                )
            else:
                return message.reply_html(text="❌ مشکلی پیش آمده، مجدد تلاش کنید")
        elif ex_step[0] == 'withdrawal':
            cs.execute(f"SELECT * FROM {utl.withdrawal} WHERE id={int(ex_step[1])}")
            row_withdrawal = cs.fetchone()
            if row_withdrawal is None:
                return message.reply_html(text="❌ خطای ناشناخته!")
            elif ex_step[2] == 'amount':
                amount = int(text)
                if amount < row_admin['min_withdrawal']:
                    return message.reply_html(text=f"حداقل مبلغ قابل برداشت {row_admin['min_withdrawal']} تومان است", reply_to_message_id=message_id)
                if amount > row_user['balance']:
                    return message.reply_html(text=f"مبلغ درخواستی باید حداکثر {row_user['balance']} تومان باشد", reply_to_message_id=message_id)
                cs.execute(f"UPDATE {utl.withdrawal} SET amount={amount} WHERE id={row_withdrawal['id']}")
                cs.execute(f"UPDATE {utl.users} SET step='{ex_step[0]};{ex_step[1]};card' WHERE user_id={from_id}")
                return message.reply_html(
                    text="💳 درخواست تسویه حساب به دو صورت قابل انجام است ...\n\n"
                        "# شبای خود را ارسال کنید ( بدون IR)\n"
                        "1️⃣ برای ثبت درخواست برداشت بدون کسر کارمزد شماره\n\n"
                        "2️⃣ برای ثبت درخواست با کسر کارمزد  شماره #کارت خود را ارسال کنید:"
                )
            elif ex_step[2] == 'card':
                cs.execute(f"UPDATE {utl.withdrawal} SET card='{text}' WHERE id={row_withdrawal['id']}")
                cs.execute(f"UPDATE {utl.users} SET step='{ex_step[0]};{ex_step[1]};name' WHERE user_id={from_id}")
                return message.reply_html(text="☑️ نام و نام خانوادگی خود را بطور کامل و صحیح ارسال کنید:")
            elif ex_step[2] == 'name':
                row_withdrawal['name'] = text
                cs.execute(f"UPDATE {utl.withdrawal} SET name='{row_withdrawal['name']}',status=1 WHERE id={row_withdrawal['id']}")
                cs.execute(f"UPDATE {utl.users} SET balance=balance-{row_withdrawal['amount']},step='start' WHERE user_id={from_id}")
                bot.send_message(
                    chat_id=utl.admins[0],
                    text=f"✅ درخواست برداشت جدید با شناسه {row_withdrawal['id']}\n\n"
                        f"🔻 کاربر: <a href='tg://user?id={from_id}'>{from_id}</a> | /d_{from_id}\n"
                        f"🔻 مبلغ: {row_withdrawal['amount']} تومان\n"
                        f"🔻 صاحب کارت: {row_withdrawal['name']}\n"
                        f"🔻 شماره کارت: <code>{row_withdrawal['card']}</code>\n"
                        f"🔻 اکانت ها: /accounts_{from_id}",
                    parse_mode='html',
                    reply_markup={'inline_keyboard': [
                        [{'text': "ارسال پیام",'callback_data': f"d;{row_withdrawal['user_id']};sendmsg"}],
                        [{'text': "✅ تسویه شده ✅",'callback_data': f"withdrawal;{row_withdrawal['id']};accept"}],
                    ]}
                )
                return  message.reply_html(
                    text=f"✅ درخواست برداشت با شناسه {row_withdrawal['id']} ثبت شد\n\n"
                        f"🔻 مبلغ: {row_withdrawal['amount']} تومان\n"
                        f"🔻 صاحب کارت: {row_withdrawal['name']}\n"
                        f"🔻 شماره کارت: {row_withdrawal['card']}",
                    reply_to_message_id=message_id,
                    reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
                )
        elif text == '👤 حساب کاربری':
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE creator_user_id={from_id} AND user_id IS NOT NULL AND status=1")
            accs_active = cs.fetchone()['count']
            message.reply_html(
                text="📊 آمار اطلاعات حساب کاربری شما :\n\n"
                    f" 👤 شناسه کاربری : {from_id}\n"
                    f" 📤 اکانت های ارسال شده : {accs_active}\n"
                    f" 💸 موجودی قابل تسویه : {row_user['balance']}\n\n"
                    f"@{utl.bot_username}",
                reply_to_message_id=message_id
            )
            return
        elif text == '🌎 کشور های مجاز':
            outout = ""
            cs.execute(f"SELECT * FROM {utl.countries} WHERE is_exists=1")
            result = cs.fetchall()
            for row in result:
                outout += f"{row['name_fa']} {row['emoji']} : {row['amount']} | +{row['area_code']}\n"
            message.reply_html(
                text=f"🌎 لیست کشور های مجاز عبارتند از :\n"
                    "- - - - - - -\n"
                    f"{outout}"
            )
            return
    if from_id in utl.admins or row_user['status'] == 1:
        if text == '/panel' or text == utl.panel_var:
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
            return message.reply_html(
                text="پنل ادمین:",
                reply_markup={'resize_keyboard': True, 'keyboard': [
                    [{'text': '⚙️ تنظیمات'}, {'text': '📣 کانال ها'}, {'text': '📊 آمار'}],
                    [{'text': '👤 کاربر'}, {'text': '👤 کاربران'}],
                    [{'text': '📋 لیست ای پی ای'}, {'text': '➕ افزودن ای پی ای'}],
                    [{'text': '📋 لیست تسویه حساب'}, {'text': '📋 لیست اکانت'}],
                    [{'text': '🌏 کشور های مجاز'}],
                    [{'text': utl.menu_var}],
                ]}
            )
        if ex_step[0] == 'info_user' or ex_text[0] == '/d':
            user_id_select = int(ex_text[1]) if ex_text[0] == '/d' else int(text)
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={user_id_select}")
            row_user_select = cs.fetchone()
            if row_user_select is None:
                message.reply_html(
                    text="❌ آیدی عددی اشتباه است\n\n"
                        "❕ دقت کنید کاربر باید قبلا ربات را استارت کرده باشد"
                )
            else:
                block = 'بلاک ✅' if row_user_select['status'] == 2 else 'بلاک ❌'
                block_status = 0 if row_user_select['status'] == 2 else 2
                admin = 'ادمین ✅' if row_user_select['status'] == 1 else 'ادمین ❌'
                admin_status = 0 if row_user_select['status'] == 1 else 1
                return message.reply_html(
                    text=f"کاربر <a href='tg://user?id={row_user_select['user_id']}'>{row_user_select['user_id']}</a>",
                    reply_markup={'inline_keyboard': [
                        [{'text': "ارسال پیام",'callback_data': f"d;{row_user_select['user_id']};sendmsg"}],
                        [
                            {'text': block,'callback_data': f"d;{row_user_select['user_id']};{block_status}"},
                            {'text': admin,'callback_data': f"d;{row_user_select['user_id']};{admin_status}"}
                        ],
                        [{'text': f"موجودی: {row_user_select['balance']}",'callback_data': "nazan"}],
                        [
                            {'text': '+5000','callback_data': f"d;{row_user_select['user_id']};balance;+5000"},
                            {'text': '+1000','callback_data': f"d;{row_user_select['user_id']};balance;+1000"},
                            {'text': '-1000','callback_data': f"d;{row_user_select['user_id']};balance;-1000"},
                            {'text': '-5000','callback_data': f"d;{row_user_select['user_id']};balance;-5000"},
                        ],
                    ]}
                )
        if ex_step[0] == 'sendmsg':
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={int(ex_step[1])}")
            row_user_select = cs.fetchone()
            if row_user_select is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                try:
                    content = f"📧️ پیام از طرف پشتیبانی\n——————————————————\n{txtcap}"
                    if update.message.text:
                        bot.send_message(chat_id=row_user_select['user_id'], text=content, disable_web_page_preview=True, parse_mode='HTML',)
                    elif update.message.photo:
                        bot.send_photo(chat_id=row_user_select['user_id'], photo=update.message.photo[len(update.message.photo) - 1].file_id, caption=content, parse_mode='HTML')
                    elif update.message.video:
                        bot.send_video(chat_id=row_user_select['user_id'], caption=content, video=update.message.video.file_id, parse_mode='HTML')
                    elif update.message.audio:
                        bot.send_audio(chat_id=row_user_select['user_id'], audio=update.message.audio.file_id, caption=content,parse_mode='HTML')
                    elif update.message.voice:
                        bot.send_voice(chat_id=row_user_select['user_id'], caption=content, voice=update.message.voice.file_id,parse_mode='HTML')
                    elif update.message.document:
                        bot.send_document(chat_id=row_user_select['user_id'], caption=content, document=update.message.document.file_id,parse_mode='HTML')
                    else:
                        return message.reply_html(text="⛔️ پیام پشتیبانی نمی شود")
                    cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                    return message.reply_html(text="✅ پیام با موفقیت ارسال شد")
                except:
                    return message.reply_html(text="❌ خطای ناشناخته، دوباره تست کنید")
        if text == '👤 کاربر':
            cs.execute(f"UPDATE {utl.users} SET step='info_user;' WHERE user_id={from_id}")
            return message.reply_html(
                text="آیدی عددی کاربر را ارسال کنید:\n\n"
                    "❕ می توانید از ربات @info_tel_bot کمک بگیرید",
                reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
            )
        if ex_step[0] == 'edit_price':
            cs.execute(f"SELECT * FROM {utl.countries} WHERE id={int(ex_step[1])}")
            row_countries = cs.fetchone()
            if row_countries is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                amount = int(text)
                if amount < 0:
                    return
                cs.execute(f"UPDATE {utl.countries} SET amount={amount} WHERE id={row_countries['id']}")
                cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                return message.reply_html(text="✅ با موفقیت آپدیت شد")
        if ex_step[0] == 'set_pass':
            cs.execute(f"UPDATE {utl.admin} SET account_password='{text}'")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
            return message.reply_html(text="✅ پسورد آپدیت شد")
        if ex_step[0] == 'get_sessions':
            count = int(text)
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE status=1")
            count_accounts = cs.fetchone()['count']
            if count_accounts < 1:
                return message.reply_html(text="❌ در حال حاضر هیچ اکانتی وجود ندارد")
            elif count < 1 or count > count_accounts:
                return message.reply_html(text="❌ حداکثر می توانید {count_accounts} ارسال کنید")
            else:
                info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                if not os.path.exists(f"{directory}/data"):
                    os.mkdir(f"{directory}/data")
                if not os.path.exists(f"{directory}/data/{timestamp}"):
                    os.mkdir(f"{directory}/data/{timestamp}")
                
                count_valid = 0
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE status=1 LIMIT {count}")
                result = cs.fetchall()
                for row_mbots in result:
                    os.system(f"{utl.python_version} \"{directory}/tl_archive_session.py\" {row_mbots['uniq_id']} {from_id} {timestamp}")
                    cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={row_mbots['id']}")
                    row_mbots_select = cs.fetchone()
                    if row_mbots_select['status'] == 1:
                        try:
                            shutil.copy(f"{directory}/sessions/{row_mbots['uniq_id']}.session", f"{directory}/data/{timestamp}")
                            count_valid += 1
                        except:
                            pass
                try:
                    shutil.make_archive(base_name=f"{directory}/data/{timestamp}", format='zip', root_dir=f"{directory}/data/{timestamp}")
                    bot.send_document(
                        chat_id=from_id,
                        document=open(f"{directory}/data/{timestamp}.zip", "rb"),
                        caption=f"تعداد {count_valid} سشن",
                        parse_mode='html',
                        reply_to_message_id=message_id
                    )
                except:
                    pass
                utl.remove_path(f"{directory}/data/{timestamp}")
                utl.remove_path(f"{directory}/{timestamp}.zip")
                return info_msg.delete()
        if ex_step[0] == 'add_api':
            try:
                ex_nl_text = text.split("\n")
                if len(ex_nl_text) != 2 or len(ex_nl_text[0]) > 50 or len(ex_nl_text[1]) > 200:
                    return message.reply_html(text="❌ ورودی اشتباه")
                elif not re.findall('^[0-9]*$', ex_nl_text[0]):
                    return message.reply_html(text="❌ api id اشتباه است")
                elif not re.findall('^[0-9-a-z-A-Z]*$', ex_nl_text[1]):
                    return message.reply_html(text="❌ api hash اشتباه است")
                else:
                    api_id = int(ex_nl_text[0])
                    api_hash = ex_nl_text[1]
                    cs.execute(f"SELECT * FROM {utl.apis} WHERE api_id={api_id} OR api_hash='{api_hash}'")
                    if cs.fetchone() is not None:
                        return message.reply_html(text="❌ این ای پی ای قبلا افزوده شده")
                    else:
                        cs.execute(f"INSERT INTO {utl.apis} (api_id,api_hash) VALUES ({api_id},'{api_hash}')")
                        return message.reply_html(
                            text="✅ با موفقیت افزوده شد\n\n"
                                "ای پی ای دیگری ارسال کنید:",
                            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.panel_var}]]}
                        )
            except:
                return message.reply_html(text="❌ مطابق نمونه ارسال کنید")
        if text == '➕ افزودن ای پی ای':
            cs.execute(f"UPDATE {utl.users} SET step='add_api;' WHERE user_id={from_id}")
            return message.reply_html(
                text="مانند نمونه ارسال کنید:\n\n"
                    "مثال:\n"
                    "api id\n"
                    "api hash",
                reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.panel_var}]]}
            )
        if text == '📋 لیست ای پی ای':
            cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{utl.step_page}")
            result = cs.fetchall()
            if not result:
                return message.reply_html(text="⛔️ لیست خالی است")
            else:
                output = ""
                i = 1
                for row in result:
                    output += f"🔴️ Api ID: <code>{row['api_id']}</code>\n"
                    output += f"🔴️ Api Hash: <code>{row['api_hash']}</code>\n"
                    output += f"❌ Delete: /DeleteApi_{row['id']}\n\n"
                    i += 1
                cs.execute(f"SELECT COUNT(*) as count FROM {utl.apis}")
                rowcount = cs.fetchone()['count']
                output = f"📜 لیست ای پی ای ({rowcount})\n\n{output}"
                ob = utl.Pagination(update, "apis", output, utl.step_page, rowcount)
                return ob.process()
        if text == '📋 لیست اکانت':
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL")
            accs_all = cs.fetchone()['count']
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=0")
            accs_first_level = cs.fetchone()['count']
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=1")
            accs_active = cs.fetchone()['count']
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE user_id IS NOT NULL AND status=3")
            accs_waite_exit = cs.fetchone()['count']
            return message.reply_html(
                text="📋 اکانت ها",
                reply_markup={'inline_keyboard': [
                    [{'text': f"💢 همه ({accs_all}) 💢", 'callback_data': f"pg;accounts;1"}],
                    [
                        {'text': f"⛔️ لاگ اوت ({accs_first_level})", 'callback_data': f"pg;first_level;1"},
                        {'text': f"✅ فعال ({accs_active})", 'callback_data': f"pg;submitted;1"}
                    ],
                    [
                        {'text': f"♻️ در انتظار خروج ({accs_waite_exit})", 'callback_data': f"pg;waite_exit;1"}
                    ],
                    [{'text': "👇 دستورات 👇", 'callback_data': "nazan"}],
                    [{'text': "✔️ حذف اکانت های لاگ اوت ✔️", 'callback_data': "gc;delete_logout;none"}],
                    [{'text': "✔️ ترک گروه و کانال ها ✔️", 'callback_data': "gc;leave_channel;none"}],
                    [{'text': "✔️ حذف پیوی ها ✔️", 'callback_data': "gc;leave_private;none"}],
                    [{'text': "✔️ ترک کانال / گروه / حذف پیوی ها ✔️", 'callback_data': "gc;leave_chat;none"}],
                    [{'text': "✔️ حذف پسورد اکانت ها ✔️", 'callback_data': "gc;delete_password;none"}],
                    [{'text': "📥 دریافت سشن 📥", 'callback_data': "gc;get_session;none"}],
                    [{'text': "❌ حذف همگانی نشست ها ❌", 'callback_data': "gc;del_sessions;none"}],
                ]}
            )
        if text == '📋 لیست تسویه حساب':
            cs.execute(f"SELECT * FROM {utl.withdrawal} ORDER BY id DESC LIMIT 0,{utl.step_page}")
            result = cs.fetchall()
            if not result:
                return message.reply_html(text="⛔️ لیست خالی است")
            else:
                output = ""
                i = 1
                for row in result:
                    output += f"🔰 شناسه: /w_{row['id']} ({utl.status_withdrawal[row['status']]})\n"
                    i += 1
                cs.execute(f"SELECT COUNT(*) as count FROM {utl.withdrawal}")
                rowcount = cs.fetchone()['count']
                output = f"📜 لیست تسویه حساب ({rowcount})\n\n{output}"
                ob = utl.Pagination(update, "withdrawal", output, utl.step_page, rowcount)
                return ob.process()
        if ex_step[0] == 'sendmsg':
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={int(ex_step[1])}")
            row_user_select = cs.fetchone()
            if row_user_select is None:
                message.reply_html(text=f"❌ کاربر یافت نشد")
            else:
                try:
                    if message.text:
                        bot.send_message(chat_id=chat_id,disable_web_page_preview=True,parse_mode='HTML',
                        text=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                    )
                    elif message.photo:
                        bot.send_photo(chat_id=chat_id,parse_mode='HTML',
                            photo=message.photo[len(message.photo) - 1].file_id,
                            caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                        )
                    elif message.video:
                        bot.send_video(chat_id=chat_id,parse_mode='HTML',
                            video=message.video.file_id,
                            caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                        )
                    elif message.audio:
                        bot.send_audio(chat_id=chat_id,parse_mode='HTML',
                            audio=message.audio.file_id,
                            caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                        )
                    elif message.voice:
                        bot.send_voice(chat_id=chat_id,parse_mode='HTML',
                            voice=message.voice.file_id,
                            caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                        )
                    elif message.document:
                        bot.send_document(chat_id=chat_id,parse_mode='HTML',
                            document=message.document.file_id,
                            caption=f"📧️ پیام جدید از طرف پشتیبانی\n——————————————————\n{txtcap}"
                        )
                    else:
                        return message.reply_html(text="⛔️ پیام پشتیبانی نمی شود")
                    cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                    message.reply_html(text="✅ پیام با موفقیت ارسال شد")
                except:
                    message.reply_html(text="❌ مشکلی در ارسال پیام رخ داد")
        if text == '📊 آمار':
            # now = jdatetime.datetime.now()
            # time_today = jdatetime.datetime(day=(now.day-1), month=now.month, year=now.year).timestamp()
            
            outout = ""
            cs.execute(f"SELECT *,COUNT(*) as count FROM {utl.mbots} WHERE country_id>0 GROUP BY country_id")
            result = cs.fetchall()
            for row in result:
                cs.execute(f"SELECT * FROM {utl.countries} WHERE id={row['country_id']}")
                row_countries = cs.fetchone()
                outout += f"‏{row_countries['emoji']} {row_countries['name_fa']}: {row['count']}\n"

            cs.execute(f"SELECT COUNT(*) as count FROM {utl.users}")
            count_users = cs.fetchone()['count']
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.withdrawal} WHERE status=1")
            count_withdrawal_doing = cs.fetchone()['count']
            cs.execute(f"SELECT COUNT(*) as count FROM {utl.withdrawal} WHERE status=2")
            count_withdrawal_done = cs.fetchone()['count']

            message.reply_html(
                text=f"📊 آمار اکانت ها\n\n"
                    f"{outout}"
            )
            return message.reply_html(
                text=f"📊 آمار ربات\n\n"
                    f"• کل کاربران: {count_users:,}\n"
                    f"• تسویه حساب های در حال انتظار: {count_withdrawal_doing:,}\n"
                    f"• تسویه حساب های انجام شده: {count_withdrawal_done:,}\n"
                    f"\n"
                    f""
            )
        if ex_step[0] == 'panel_channels':
            if text == utl.back_var:
                text = '📣 کانال ها'
            elif ex_step[1] == 'none':
                if text == '📣 اجباری یک':
                    cs.execute(f"UPDATE {utl.users} SET step='panel_channels;set;channel_1' WHERE user_id={from_id}")
                    return message.reply_html(
                        text="یک پست از کانال فوروارد کنید:",
                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                    )
                elif text == '📣 اجباری دو':
                    cs.execute(f"UPDATE {utl.users} SET step='panel_channels;set;channel_2' WHERE user_id={from_id}")
                    return message.reply_html(
                        text="یک پست از کانال فوروارد کنید:",
                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                    )
                elif text == '📣 اجباری سه':
                    cs.execute(f"UPDATE {utl.users} SET step='panel_channels;set;channel_3' WHERE user_id={from_id}")
                    return message.reply_html(
                        text="یک پست از کانال فوروارد کنید:",
                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                    )
                elif text == '📣 پشتیبانی':
                    cs.execute(f"UPDATE {utl.users} SET step='panel_channels;support' WHERE user_id={from_id}")
                    return message.reply_html(
                        text="آیدی (یوزرنیم) پشتیبانی را ارسال کنید:",
                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                    )
            elif ex_step[1] == 'set':
                if not message.forward_from_chat:
                    return message.reply_html(text="❌ یک پست از کانال فوروارد کنید")
                elif not message.forward_from_chat.username:
                    return message.reply_html(text="❌ کانال باید عمومی باشد")
                elif bot.get_chat_member(chat_id=message.forward_from_chat.id, user_id=utl.bot_id).status == "left":
                    return message.reply_html(text="❌ مطمئن شوید که ربات در کانال ادمین است.")
                else:
                    cs.execute(f"UPDATE {utl.admin} SET {ex_step[2]}='{message.forward_from_chat.username}'")
                    cs.execute(f"UPDATE {utl.users} SET step='panel_channels;none' WHERE user_id={from_id}")
                    message.reply_html(text="✅ با موفقیت ثبت شد")
                    text = '📣 کانال ها'
            elif ex_step[1] == 'support':
                cs.execute(f"UPDATE {utl.admin} SET {ex_step[1]}='{text}'")
                cs.execute(f"UPDATE {utl.users} SET step='panel_channels;none' WHERE user_id={from_id}")
                message.reply_html(text="✅ با موفقیت ثبت شد")
                text = '📣 کانال ها'
        if text == '📣 کانال ها':
            outout = ""
            outout += f"کانال 1: {row_admin['channel_1']}\n❌/delch_1\n\n" if row_admin['channel_1'] is not None else f"کانال 1: ثبت نشده\n"
            outout += f"کانال 2: {row_admin['channel_2']}\n❌/delch_2\n\n" if row_admin['channel_2'] is not None else f"کانال 2: ثبت نشده\n"
            outout += f"کانال 3: {row_admin['channel_3']}\n❌/delch_3\n\n" if row_admin['channel_3'] is not None else f"کانال 3: ثبت نشده\n"
            outout += f"پشتیبانی: @{row_admin['support']}" if row_admin['support'] is not None else f"پشتیبانی: ثبت نشده\n"
            cs.execute(f"UPDATE {utl.users} SET step='panel_channels;none' WHERE user_id={from_id}")
            return message.reply_html(
                text="کانال ها:\n\n"
                    f"{outout}",
                reply_markup={'resize_keyboard': True, 'keyboard': [
                    [{'text': '📣 اجباری سه'}, {'text': '📣 اجباری دو'}, {'text': '📣 اجباری یک'}],
                    [{'text': '📣 پشتیبانی'}],
                    [{'text': utl.panel_var}],
                ]}
            )
        if ex_step[0] == 'users':
            if text == utl.back_var:
                text = '👤 کاربران'
            elif text == '👤 همه':
                selected_pages = 0
                i = selected_pages + 1
                cs.execute(f"SELECT * FROM {utl.users} ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                result = cs.fetchall()
                if not result:
                    return message.reply_html(text="⛔️ لیست خالی است")
                else:
                    output = ""
                    for row in result:
                        output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                        i += 1
                    cs.execute(f"SELECT COUNT(*) as count FROM {utl.users}")
                    rowcount = cs.fetchone()['count']
                    ob = utl.Pagination(update, "users", f"📜 لیست کاربران ({rowcount})\n➖➖➖➖➖➖➖\n{output}", utl.step_page, rowcount)
                    return ob.process()
            elif text == '👤 بلاک ها':
                selected_pages = 0
                i = selected_pages + 1
                cs.execute(f"SELECT * FROM {utl.users} WHERE status=2 ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                result = cs.fetchall()
                if not result:
                    return message.reply_html(text="⛔️ لیست خالی است")
                else:
                    output = ""
                    for row in result:
                        output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                        i += 1
                    cs.execute(f"SELECT COUNT(*) as count FROM {utl.users} WHERE status=2")
                    rowcount = cs.fetchone()['count']
                    ob = utl.Pagination(update, "blocked",f"📜 لیست بلاک ها ({rowcount})\n\n{output}", utl.step_page, rowcount)
                    return ob.process()
            elif text == '👤 ادمین ها':
                selected_pages = 0
                i = selected_pages + 1
                cs.execute(f"SELECT * FROM {utl.users} WHERE status=1 ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
                result = cs.fetchall()
                if not result:
                    return message.reply_html(text="⛔️ لیست خالی است")
                else:
                    output = ""
                    for row in result:
                        output += f"{i}. <a href='tg://user?id={row['user_id']}'>{row['user_id']}</a> (/d_{row['user_id']})\n"
                        i += 1
                    cs.execute(f"SELECT COUNT(*) as count FROM {utl.users} WHERE status=1")
                    rowcount = cs.fetchone()['count']
                    ob = utl.Pagination(update, "admins", f"📜 لیست ادمین ها ({rowcount})\n\n{output}", utl.step_page, rowcount)
                    return ob.process()
            elif text == '👤 پیام همگانی':
                cs.execute(f"UPDATE {utl.users} SET step='users;send;message' WHERE user_id={from_id}")
                return message.reply_html(
                    text="پیام خود را ارسال کنید:",
                    reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                )
            elif text == '👤 فوروارد همگانی':
                cs.execute(f"UPDATE {utl.users} SET step='users;send;forward' WHERE user_id={from_id}")
                return message.reply_html(
                    text="پیام خود را فوروارد کنید:",
                    reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.back_var}, {'text': utl.panel_var}]]}
                )
            elif ex_step[1] == 'send':
                if ex_step[2] == 'message':
                    if not message.text and not message.photo and not message.video and not message.audio and not message.voice and not message.document:
                        return message.reply_html(text="⛔️ پیام پشتیبانی نمی شود")
                    cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                    info_msg = message.reply_html(text="در حال ارسال...")
                    cs.execute(f"SELECT * FROM {utl.users}")
                    result = cs.fetchall()
                    count_users = len(result)
                    count_success = 0
                    count_failed = 0
                    time_start = time.time()
                    for row in result:
                        try:
                            if message.text:
                                bot.send_message(chat_id=row['user_id'],disable_web_page_preview=True,parse_mode='HTML',text=txtcap)
                            elif message.photo:
                                bot.send_photo(chat_id=row['user_id'],parse_mode='HTML',photo=message.photo[len(message.photo) - 1].file_id,caption=txtcap)
                            elif message.video:
                                bot.send_video(chat_id=row['user_id'],parse_mode='HTML',video=message.video.file_id,caption=txtcap)
                            elif message.audio:
                                bot.send_audio(chat_id=row['user_id'],parse_mode='HTML',audio=message.audio.file_id,caption=txtcap)
                            elif message.voice:
                                bot.send_voice(chat_id=row['user_id'],parse_mode='HTML',voice=message.voice.file_id,caption=txtcap)
                            elif message.document:
                                bot.send_document(chat_id=row['user_id'],parse_mode='HTML',document=message.document.file_id,caption=txtcap)
                            count_success += 1
                        except:
                            count_failed += 1
                        if (time.time() - time_start) >= 5:
                            time_start = time.time()
                            try:
                                info_msg.edit_text(
                                    f"وضعیت: در حال ارسال ... ♻️\n\n"
                                    f"👥 کل کاربران: {count_users}\n"
                                    f"✅ ارسال موفق: {count_success}\n"
                                    f"❌ ارسال ناموفق: {count_failed}\n\n"
                                    f"❕ ارسال ناموفق بدلیل بلاک کردن ربات یا دیلیت اکانت کاربر است\n"
                                )
                            except:
                                pass
                    info_msg.edit_text(
                        text=f"وضعیت: تمام شده ✅\n\n"
                            f"👥 کل کاربران: {count_users}\n"
                            f"✅ ارسال موفق: {count_success}\n"
                            f"❌ ارسال ناموفق: {count_failed}\n\n"
                            f"❕ ارسال ناموفق بدلیل بلاک کردن ربات یا دیلیت اکانت کاربر است\n"
                    )
                    message.reply_html(text="✅ پیام به همه کاربران فوروارد شد")
                    text = '👤 کاربران'
                elif ex_step[2] == 'forward':
                    cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={from_id}")
                    info_msg = message.reply_html(text="در حال ارسال...")
                    cs.execute(f"SELECT * FROM {utl.users}")
                    result = cs.fetchall()
                    count_users = len(result)
                    count_success = 0
                    count_failed = 0
                    time_start = time.time()
                    for row in result:
                        try:
                            bot.forward_message(chat_id=row['user_id'], from_chat_id=from_id, message_id=message_id)
                            count_success += 1
                        except:
                            count_failed += 1
                        if (time.time() - time_start) >= 5:
                            time_start = time.time()
                            try:
                                info_msg.edit_text(
                                    f"وضعیت: در حال ارسال ... ♻️\n\n"
                                    f"👥 کل کاربران: {count_users}\n"
                                    f"✅ ارسال موفق: {count_success}\n"
                                    f"❌ ارسال ناموفق: {count_failed}\n\n"
                                    f"❕ ارسال ناموفق بدلیل بلاک کردن ربات یا دیلیت اکانت کاربر است\n"
                                )
                            except:
                                pass
                    info_msg.edit_text(
                        f"وضعیت: تمام شده ✅\n\n"
                        f"👥 کل کاربران: {count_users}\n"
                        f"✅ ارسال موفق: {count_success}\n"
                        f"❌ ارسال ناموفق: {count_failed}\n\n"
                        f"❕ ارسال ناموفق بدلیل بلاک کردن ربات یا دیلیت اکانت کاربر است\n"
                    )
                    message.reply_html(text="✅ پیام به همه کاربران فوروارد شد")
                    text = '👤 کاربران'
        if text == '👤 کاربران':
            cs.execute(f"UPDATE {utl.users} SET step='users;none' WHERE user_id={from_id}")
            return message.reply_html(
                text="کاربران:",
                reply_markup={'resize_keyboard': True, 'keyboard': [
                    [{'text': '👤 ادمین ها'}, {'text': '👤 بلاک ها'}, {'text': '👤 همه'}],
                    [{'text': '👤 پیام همگانی'}, {'text': '👤 فوروارد همگانی'}],
                    [{'text': utl.panel_var}],
                ]}
            )
        if text == '⚙️ تنظیمات':
            account_password = row_admin['account_password'] if row_admin['account_password'] is not None else "ثبت نشده"
            api_per_number = f"ثبت {row_admin['api_per_number']} اکانت در هر api" if row_admin['api_per_number'] <= 5 else f"⚠️ ثبت {row_admin['api_per_number']} اکانت در هر api ⚠️"
            change_pass = "✅ تغییر / تنظیم پسورد روی اکانت ✅" if row_admin['change_pass'] else "❌ تغییر / تنظیم پسورد روی اکانت ❌"
            is_change_profile = "✅ تنظیم اسم، بیو و پروفایل روی اکانت ✅" if row_admin['is_change_profile'] else "❌ تنظیم اسم، بیو و پروفایل روی اکانت ❌"
            is_set_username = "✅ تنظیم یوزرنیم روی اکانت ✅" if row_admin['is_set_username'] else "❌ تنظیم یوزرنیم روی اکانت ❌"
            onoff_bot = "✅ ربات روشن است" if row_admin['onoff_bot'] else "❌ ربات خاموش است"
            onoff_account = "✅ ارسال اکانت روشن است" if row_admin['onoff_account'] else "❌ ارسال اکانت خاموش است"
            onoff_withdrawal = "✅ تسویه حساب روشن است" if row_admin['onoff_withdrawal'] else "❌ تسویه حساب خاموش است"
            onoff_support = "✅ پشتیبانی روشن است" if row_admin['onoff_support'] else "❌ پشتیبانی خاموش است"
            message.reply_html(
                text="⚙️ تنظیمات:",
                reply_markup={'inline_keyboard': [
                    [{'text': f"پسورد: {account_password}",'callback_data': "settings;account_password"}],
                    [{'text': api_per_number,'callback_data': "nazan"}],
                    [
                        {'text': '+10','callback_data': "settings;api_per_number;+10"},
                        {'text': '+5','callback_data': "settings;api_per_number;+5"},
                        {'text': '+1','callback_data': "settings;api_per_number;+1"},
                        {'text': '-1','callback_data': "settings;api_per_number;-1"},
                        {'text': '-5','callback_data': "settings;api_per_number;-5"},
                        {'text': '-10','callback_data': "settings;api_per_number;-10"},
                    ],
                    [{'text': f"خروج از اکانت بعد از {row_admin['time_logout_account']} ثانیه",'callback_data': "nazan"}],
                    [
                        {'text': '+10','callback_data': "settings;time_logout_account;+100"},
                        {'text': '+5','callback_data': "settings;time_logout_account;+10"},
                        {'text': '+1','callback_data': "settings;time_logout_account;+5"},
                        {'text': '-1','callback_data': "settings;time_logout_account;-5"},
                        {'text': '-5','callback_data': "settings;time_logout_account;-10"},
                        {'text': '-10','callback_data': "settings;time_logout_account;-100"},
                    ],
                    [{'text': change_pass,'callback_data': "settings;change_pass"}],
                    [{'text': is_change_profile,'callback_data': "settings;is_change_profile"}],
                    [{'text': is_set_username,'callback_data': "settings;is_set_username"}],
                    [{'text': "〰️〰️〰️ روشن / خاموش〰️〰️〰️",'callback_data': "nazan"}],
                    [{'text': onoff_bot,'callback_data': "settings;onoff_bot"}],
                    [{'text': onoff_account,'callback_data': "settings;onoff_account"}],
                    [{'text': onoff_withdrawal,'callback_data': "settings;onoff_withdrawal"}],
                    [{'text': onoff_support,'callback_data': "settings;onoff_support"}],
                ]}
            )
            return
        if text == '🌏 کشور های مجاز':
            message.reply_html(
                text=f"🌎 تنظیمات کشور های مجاز :\n\n"
                    f"❌ حذف همه کشور ها: /delc_all\n"
                    f"✅ افزودن همه کشور ها: /addc_all"
            )
            i = 0
            outout = ""
            cs.execute(f"SELECT * FROM {utl.countries}")
            result = cs.fetchall()
            count = len(result)
            for row in result:
                i += 1
                is_exists = f"✅ /delc_{row['id']} | 📝 /editc_{row['id']} |" if row['is_exists'] else f"❌ /addc_{row['id']} | 📝 /editc_{row['id']} |"
                outout += f"‏ {row['name_fa']} {row['emoji']} : {row['amount']} | +{row['area_code']}\n{is_exists}\n\n"
                if i % 45 == 0 or count == i:
                    message.reply_html(outout)
                    outout = ""
            return
        if ex_text[0] == '/vip':
            day = int(ex_text[1])
            user_id_select = int(ex_text[2])
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={user_id_select}")
            row_user_select = cs.fetchone()
            if row_user_select is None:
                return message.reply_html(text="❌ کاربر یافت نشد")
            else:
                if row_user_select['subscription'] > timestamp:
                    new_subscription = row_user_select['subscription'] + int(day * 86400)
                else:
                    new_subscription = timestamp + int(day * 86400)
                cs.execute(f"UPDATE {utl.users} SET subscription={new_subscription} WHERE user_id={row_user_select['user_id']}")
                message.reply_html(text="✅ اشتراک با موفقیت ارسال شد")
                return bot.send_message(
                    chat_id=row_user_select['user_id'],
                    text=f"🎁 کاربر گرامی شما از طرف مدیریت {day} روز اشتراک دریافت کردید"
                )
        if ex_text[0] == "/delc":
            if ex_text[1] == 'all':
                cs.execute(f"UPDATE {utl.countries} SET is_exists=0")
                return message.reply_html(text="✅ انجام شد", reply_to_message_id=message_id)
            else:
                cs.execute(f"SELECT * FROM {utl.countries} WHERE id={int(ex_text[1])}")
                row_countries = cs.fetchone()
                if row_countries is None:
                    return message.reply_html(text="❌ شناسه اشتباه است")
                else:
                    cs.execute(f"UPDATE {utl.countries} SET is_exists=0 WHERE id={row_countries['id']}")
                    return message.reply_html(text="✅ کشور از لیست کشور های مجاز حذف شد", reply_to_message_id=message_id)
        if ex_text[0] == "/editc":
            cs.execute(f"SELECT * FROM {utl.countries} WHERE id={int(ex_text[1])}")
            row_countries = cs.fetchone()
            if row_countries is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                cs.execute(f"UPDATE {utl.users} SET step='edit_price;{row_countries['id']}' WHERE user_id={from_id}")
                return message.reply_html(
                    text=f"هزینه جدید را برای شماره های {row_countries['emoji']} {row_countries['name_fa']} وارد کنید:\n\n"
                        "کنسل: /panel"
                )
        if ex_text[0] == "/addc":
            if ex_text[1] == 'all':
                cs.execute(f"UPDATE {utl.countries} SET is_exists=1")
                return message.reply_html(text="✅ انجام شد", reply_to_message_id=message_id)
            else:
                cs.execute(f"SELECT * FROM {utl.countries} WHERE id={int(ex_text[1])}")
                row_countries = cs.fetchone()
                if row_countries is None:
                    return message.reply_html(text="❌ شناسه اشتباه است")
                else:
                    cs.execute(f"UPDATE {utl.countries} SET is_exists=1 WHERE id={row_countries['id']}")
                    return message.reply_html(text="✅ کشور به لیست کشور های مجاز اضافه شد", reply_to_message_id=message_id)
        if ex_text[0] == "/del":
            if ex_text[1] == '1':
                cs.execute(f"UPDATE {utl.admin} SET channel_1=null")
                return message.reply_html(text="✅ با موفقیت بروزرسانی شد")
            elif ex_text[1] == '2':
                cs.execute(f"UPDATE {utl.admin} SET channel_2=null")
                return message.reply_html(text="✅ با موفقیت بروزرسانی شد")
            elif ex_text[1] == '3':
                cs.execute(f"UPDATE {utl.admin} SET channel_3=null")
                return message.reply_html(text="✅ با موفقیت بروزرسانی شد")
            elif ex_text[1] == 'pv':
                cs.execute(f"UPDATE {utl.admin} SET channel_pv_id=null,channel_pv_link=null")
                return message.reply_html(text="✅ با موفقیت بروزرسانی شد")
        if ex_text[0] == '/w':
            cs.execute(f"SELECT * FROM {utl.withdrawal} WHERE id={int(ex_text[1])}")
            row_withdrawal = cs.fetchone()
            if row_withdrawal is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                inline_keyboard = [[{'text': "ارسال پیام",'callback_data': f"d;{row_withdrawal['user_id']};sendmsg"}]]
                if row_withdrawal['status'] == 1:
                    inline_keyboard.append([{'text': "✅ تسویه شده ✅",'callback_data': f"withdrawal;{row_withdrawal['id']};accept"}])
                return bot.send_message(
                    chat_id=from_id,
                    text=f"🔰 جزئیات  درخواست برداشت {row_withdrawal['id']}\n\n"
                        f"🔻 کاربر: <a href='tg://user?id={from_id}'>{from_id}</a> | /d_{from_id}\n"
                        f"🔻 وضعیت: {utl.status_withdrawal[row_withdrawal['status']]}\n"
                        f"🔻 مبلغ: {row_withdrawal['amount']} تومان\n"
                        f"🔻 صاحب کارت: {row_withdrawal['name']}\n"
                        f"🔻 شماره کارت: <code>{row_withdrawal['card']}</code>\n"
                        f"🔻 اکانت ها: /accounts_{from_id}",
                    parse_mode='html',
                    reply_markup={'inline_keyboard': inline_keyboard}
                )
        if ex_text[0] == '/accounts':
            user_id_select = int(ex_text[1])
            selected_pages = 0
            i = selected_pages + 1
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE creator_user_id={user_id_select} AND user_id IS NOT NULL ORDER BY id DESC LIMIT {selected_pages},{utl.step_page}")
            result = cs.fetchall()
            if not result:
                return message.reply_html(text="⛔️ لیست خالی است")
            else:
                output = ""
                for row in result:
                    if row['status'] == 2:
                        output += f"{i}. Phone: <code>{row['phone']}</code>\n"
                        output += f"⛔ Restrict: ({utl.convert_time((row['end_restrict'] - timestamp),2)})\n"
                    else:
                        output += f"{i}. phone: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ Status: /status_{row['id']}\n"
                    if row['status'] != 0:
                        output += f"🔸️ Get Session: /session_{row['id']}\n"
                        output += f"🔸️ Delete Sessions: /del_session_{row['id']}\n"
                        output += f"🔸️ Delete Password: /del_password_{row['id']}\n"
                    output += "\n"
                    i += 1
                cs.execute(f"SELECT COUNT(*) as count FROM {utl.mbots} WHERE creator_user_id={user_id_select} AND user_id IS NOT NULL")
                rowcount = cs.fetchone()['count']
                ob = utl.Pagination(update, f"accountsu_{user_id_select}", f"📜 لیست اکانت های کاربر {user_id_select} ({rowcount})\n\n{output}", utl.step_page, rowcount)
                return ob.process()
        if ex_text[0] == '/status':
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_text[1])}")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                os.system(f"{utl.python_version} \"{directory}/tl_account_status.py\" {row_mbots['uniq_id']} {from_id} check")
                return info_msg.delete()
        if ex_text[0] == '/session':
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_text[1])}")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                return message.reply_html(text="❌ شناسه اشتباه است", reply_to_message_id=message_id)
            else:
                info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                os.system(f"{utl.python_version} \"{directory}/tl_archive_session.py\" {row_mbots['uniq_id']} {from_id} {timestamp}")

                cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={row_mbots['id']}")
                row_mbots = cs.fetchone()
                if row_mbots['status'] == 1:
                    if not os.path.exists(f"{directory}/data"):
                        os.mkdir(f"{directory}/data")
                    if not os.path.exists(f"{directory}/data/{timestamp}"):
                        os.mkdir(f"{directory}/data/{timestamp}")
                    try:
                        shutil.copy(f"{directory}/sessions/{row_mbots['uniq_id']}.session", f"{directory}/data/{timestamp}")
                        shutil.make_archive(base_name=f"{directory}/data/{timestamp}", format='zip', root_dir=f"{directory}/data/{timestamp}")
                        bot.send_document(
                            chat_id=from_id,
                            document=open(f"{directory}/data/{timestamp}.zip", "rb"),
                            caption=f"سشن اکانت <code>{row_mbots['phone']}</code>",
                            parse_mode='html',
                            reply_to_message_id=message_id
                        )
                    except:
                        pass
                    utl.remove_path(f"{directory}/data/{timestamp}")
                    utl.remove_path(f"{directory}/{timestamp}.zip")
                return info_msg.delete()
        if ex_text[0] == '/del':
            if ex_text[1] == 'session':
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_text[2])}")
                row_mbots = cs.fetchone()
                if row_mbots is None:
                    return message.reply_html(text="❌ شناسه اشتباه است")
                else:
                    info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                    os.system(f"{utl.python_version} \"{directory}/tl_delete_sessions.py\" {row_mbots['uniq_id']} {from_id} one")
                    return info_msg.delete()
            elif ex_text[1] == 'password':
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_text[2])}")
                row_mbots = cs.fetchone()
                if row_mbots is None:
                    return message.reply_html(text="❌ شناسه اشتباه است")
                else:
                    info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                    os.system(f"{utl.python_version} \"{directory}/tl_delete_password.py\" {row_mbots['uniq_id']} {from_id} one")
                    return info_msg.delete()
        if ex_text[0] == '/sessions':
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={int(ex_text[1])}")
            row_mbots = cs.fetchone()
            if row_mbots is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                info_msg = message.reply_html(text="♻️ در حال پردازش، منتظر باشید …", reply_to_message_id=message_id)
                os.system(f"{utl.python_version} \"{directory}/tl_account_status.py\" {row_mbots['uniq_id']} {from_id} sessions")
                return info_msg.delete()
        if ex_text[0] == '/DeleteApi':
            cs.execute(f"SELECT * FROM {utl.apis} WHERE id={int(ex_text[1])}")
            row_apis = cs.fetchone()
            if row_apis is None:
                return message.reply_html(text="❌ شناسه اشتباه است")
            else:
                cs.execute(f"DELETE FROM {utl.apis} WHERE id={row_apis['id']}")
                return message.reply_html(text="✅ با موفقیت حذف شد")
        if ex_text[0] == '/DelAdmin':
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={int(ex_text[1])}")
            row_users = cs.fetchone()
            if row_users is None:
                return message.reply_html(text="❌ شناسه یافت نشد")
            elif row_users['status'] != 1:
                return message.reply_html(text="❌ این کاربر ادمین نیست")
            else:
                cs.execute(f"UPDATE {utl.users} SET status=0 WHERE user_id={row_users['user_id']}")
                return message.reply_html(text=f"✅ کاربر یا موفقیت از ادمینی عزل شد")
        if ex_text[0] == '/unblock':
            cs.execute(f"SELECT * FROM {utl.users} WHERE user_id={int(ex_text[1])}")
            row_users = cs.fetchone()
            if row_users is None:
                return message.reply_html(text="❌ شناسه یافت نشد")
            elif row_users['status'] != 'block':
                return message.reply_html(text="❌ این کاربر بلاک نیست")
            else:
                cs.execute(f"UPDATE {utl.users} SET status=0 WHERE user_id={row_users['user_id']}")
                return message.reply_html(text="✅ کاربر یا موفقیت آنبلاک شد")
    

if __name__ == '__main__':
    updater = telegram.ext.Updater(utl.token)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(telegram.ext.MessageHandler(telegram.ext.Filters.chat_type.private & telegram.ext.Filters.update.message & telegram.ext.Filters.update, private_process, run_async=True))
    dispatcher.add_handler(telegram.ext.CallbackQueryHandler(callbackquery_process, run_async=True))
    
    updater.start_polling(drop_pending_updates=True)
    updater.idle()
