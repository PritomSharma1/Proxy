import os, sys, time, telethon, telethon.sync, utility as utl


for index, arg in enumerate(sys.argv):
    if index == 1:
        mbots_uniq_id = arg
    elif index == 2:
        message_id = int(arg)
    elif index == 3:
        type_ = arg

directory = os.path.dirname(os.path.abspath(__file__))
timestamp = int(time.time())

cs = utl.Database()
cs = cs.data()

cs.execute(f"SELECT * FROM {utl.admin}")
row_admin = cs.fetchone()

cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{mbots_uniq_id}'")
row_mbots = cs.fetchone()
try:
    client = telethon.sync.TelegramClient(session=f"{directory}/sessions/{row_mbots['uniq_id']}",api_id=row_mbots['api_id'],api_hash=row_mbots['api_hash'])
    client.connect()
    if type_ == 'code':
        me = client.send_code_request(phone=row_mbots['phone'])
        cs.execute(f"UPDATE {utl.mbots} SET phone_code_hash='{me.phone_code_hash}' WHERE id={row_mbots['id']}")
        cs.execute(f"UPDATE {utl.users} SET step='add_acc;code;{row_mbots['id']}' WHERE user_id={row_mbots['creator_user_id']}")
        utl.bot.send_message(
            chat_id=row_mbots['creator_user_id'],
            text="کد را در خط اول و پسورد را در خط دوم وارد کنید:\n\n"
                "مثال:\n"
                "12345\n"
                "password\n\n"
                "⚠️ اگر اکانت پسورد ندارد فقط کد را وارد کنید"
        )
    elif type_ == 'auth':
        is_ok = True
        try:
            me = client.sign_in(phone=row_mbots['phone'], phone_code_hash=row_mbots['phone_code_hash'], code=row_mbots['code'])
        except telethon.errors.PhoneCodeInvalidError as e:
            utl.bot.send_message(chat_id=row_mbots['creator_user_id'],text="❌ کد اشتباه است")
            is_ok = False
        except telethon.errors.SessionPasswordNeededError as e:
            if row_mbots['password'] is None:
                utl.bot.send_message(
                    chat_id=row_mbots['creator_user_id'],
                    text="❌ اکانت دارای پسورد است!\n\n"
                        "⚠️ کد را در خط اول و پسورد را در خط دوم ارسال کنید",
                )
                is_ok = False
            else:
                me = client.sign_in(password=row_mbots['password'])
        if is_ok:
            cs.execute(f"UPDATE {utl.mbots} SET user_id={int(me.id)},status=3,last_check_exit_at={timestamp} WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id={row_mbots['creator_user_id']}")
            utl.bot.send_message(
                chat_id=row_mbots['creator_user_id'],
                text=f"🔐 اکانت {row_mbots['phone']} با موفقیت دریافت شد\n\n"
                    f"👈 جهت دریافت موجودی لطفا از اکانت خارج شوید و پس از {row_admin['time_logout_account']} ثانیه روی دکمه ثبت نهایی کلیک کنید",
                reply_markup={'inline_keyboard': [
                    [{'text': "ثبت نهایی", 'callback_data': f"confirm_phone;{row_mbots['id']}"}]
                ]}
            )
    elif type_ == 'session':
        is_ok = True
        for session in client(telethon.functions.account.GetAuthorizationsRequest()).authorizations:
            if not session.current:
                try:
                    client(telethon.functions.account.ResetAuthorizationRequest(hash=session.hash))
                except:
                    is_ok = False
        if is_ok:
            for session in client(telethon.functions.account.GetAuthorizationsRequest()).authorizations:
                if not session.current:
                    is_ok = False
        if not is_ok:
            utl.bot.send_message(
                chat_id=row_mbots['creator_user_id'],
                text="❌ هنوز خارج نشده اید!",
                reply_to_message_id=message_id
            )
        else:
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={row_mbots['id']}")
            row_mbots = cs.fetchone()
            if row_mbots['status'] != 3:
                try:
                    utl.bot.delete_message(chat_id=row_mbots['creator_user_id'], message_id=message_id)
                except:
                    pass
                exit()
            cs.execute(f"UPDATE {utl.mbots} SET status=1 WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET balance=balance+{row_mbots['amount']} WHERE user_id={row_mbots['creator_user_id']}")
            utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text=f"✅ اکانت {row_mbots['phone']} ثبت و {row_mbots['amount']} تومان به حساب شما افزوده شد")
            try:
                utl.bot.delete_message(chat_id=row_mbots['creator_user_id'], message_id=message_id)
            except:
                pass
            utl.bot.send_message(
                chat_id=utl.admins[0],
                text=f"✅ اکانت جدید ثبت شد\n\n"
                    f"🔻 کاربر: <a href='tg://user?id={row_mbots['creator_user_id']}'>{row_mbots['creator_user_id']}</a> | /d_{row_mbots['creator_user_id']}\n"
                    f"🔻 شماره: <code>{row_mbots['phone']}</code>\n"
                    f"🔻 اکانت های کاربر: /accounts_{row_mbots['creator_user_id']}",
                parse_mode='html',
                reply_markup={'inline_keyboard': [[{'text': "ارسال پیام",'callback_data': f"d;{row_mbots['creator_user_id']};sendmsg"}]]}
            )
except telethon.errors.PhoneCodeExpiredError as e:
    utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ کد منقضی شده است")
except telethon.errors.PhoneNumberInvalidError as e:
    utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ شماره اشتباه است")
except Exception as e:
    error = str(e)
    print(f"Error2: {error}")
    if "database is locked" in error:
        utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ خطای غیر منتظره، دوباره تلاش کنید")
    elif "You have tried logging in too many times" in error:
        utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ شما با این شماره بیش از حد تلاش کردید، بعد از مدتی مجدد تلاش کنید")
    elif "The used phone number has been banned" in error:
        utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ شماره مسدود شده است")
    elif "The password (and thus its hash value) you entered is invalid" in error:
        utl.bot.send_message(chat_id=row_mbots['creator_user_id'], text="❌ پسورد اشتباه است")
